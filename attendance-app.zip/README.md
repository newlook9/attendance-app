# Face Attendance (Android, offline)
Push to GitHub -> Actions tab -> "Build APK" -> download artifact `attendance-apk` -> unzip -> install app-debug.apk.
Face library and models are downloaded at build time and bundled in the APK, so the app works fully offline.
Default admin PIN: 1234
